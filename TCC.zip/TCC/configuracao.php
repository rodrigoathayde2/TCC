<?php include_once 'php/header.php'?>
	<title>Cadastro</title>
	
				<!-- cadastro -->
			<link href="css\cadastro.css" type="text/css" rel="stylesheet">
			<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
			<!-- Optional -->
			<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
			<script href="js/verificar.js"></script>	
	  
	  
	
	  
	  	  <!--Formulário-->

		  	
	
	
		<form  name="cadastro"class="form-horizontal" action="php/inserirCadastro.php" method="POST">
		<fieldset>
			<div class="panel panel-primary">
				<div class="panel-heading">CONFIGURAÇÃO</div>
				
				<div class="panel-body">
				<div class="form-group">		
				</div>

			<!-- Nome-->
			<div class="form-group">
			  <label class="col-md-2 control-label" for="Nome">Cloro</label>  
			  <div class="col-md-8">
			  <input id="nome" name="nome" placeholder="" class="form-control input-md">
			  </div>     
			  <div class="col-md-3">
				<select id="categoria" name="categoria" class="form-control">
				
				  <option name="categoria"value="clienteInstar">Cliente Instar</option>
				  <option name="categoria"value="clienteMagazine">Cliente Magazine</option>
				  <option name="categoria"value="clienteVIP">Cliente VIP</option>
				  <option name="categoria"value="naoMembro">Não sou membro</option>
			   
				</select>
			  </div>
			</div>
				<!-- endereco-->
			
			<div class="form-group">
			  <label class="col-md-2 control-label" for="endereco">Endereço</label>  
			  <div class="col-md-8">
			  <input id="endereco" name="endereco" placeholder="" class="form-control input-md" required="" type="text">
			  </div>
			</div>


			<!-- Email-->
			<div class="form-group">
			  <label class="col-md-2 control-label" for="prependedtext">Email </label>
			  <div class="col-md-5">
				<div class="input-group">
				  <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
				  <input id="usuario" name="usuario" class="form-control" placeholder="email@email.com" required="" type="text" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" >
				</div>
			  </div>
			</div>
				<!-- cidade-->
			
				<div class="form-group">
			  <label class="col-md-2 control-label" for="prependedtext">Cidade</label>
			  <div class="col-md-5">
				<div class="input-group">
				
				  <input id="cidade" name="cidade" class="form-control" placeholder="" required="" type="text">
				</div>
			  </div>
			</div>
				<!-- estado-->
			<div class="form-group">
			  <label class="col-md-2 control-label" for="prependedtext" >Estado</label>
			  <div class="col-md-2">
				<div class="input-group">
				  
				  <input id="estado" name="estado" class="form-control" placeholder="SP" required="" type="text" maxlength ="2">
				</div>
			  </div>
			</div>


			<!-- Select categoria -->
			<div class="form-group">
				
			  <label class="col-md-2 control-label" for="selectbasic">Categoria</label>
			  
			  <div class="col-md-3">
				<select id="categoria" name="categoria" class="form-control">
				
				  <option name="categoria"value="clienteInstar">Cliente Instar</option>
				  <option name="categoria"value="clienteMagazine">Cliente Magazine</option>
				  <option name="categoria"value="clienteVIP">Cliente VIP</option>
				  <option name="categoria"value="naoMembro">Não sou membro</option>
			   
				</select>
			  </div>
				<!-- botão -->
				<div class="form-group">
				  <label class="col-md-2 control-label" for="Cadastrar"></label>
				  <div class="col-md-6">
					<button id="cadastrar" name="cadastrar" class="btn btn-success" type="Submit">Cadastrar</button>
					<button id="Cancelar" name="Cancelar" class="btn btn-danger" type="Reset">Cancelar</button>
				  </div>
				</div>

				</div>
				</div>


</fieldset>
</form>
	
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>	
	<!-- importando do JavaScript bootstrap minimizado -->  
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
		  		
<?php include_once 'php/foolder.php';?>
	  
	  
	  
	  
	  
	  
	  
	  
