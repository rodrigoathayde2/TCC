
<?php
    setlocale( LC_ALL, 'pt_BR', 'pt_BR.iso-8859-1', 'pt_BR.utf-8', 'portuguese' );
    date_default_timezone_set( 'America/Sao_Paulo' );
    
?>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

		<link rel="stylesheet" type="text/css" href="css/style">
		<!-- cadastro  -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> 
		<link href="//cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css" rel="stylesheet">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css\cadastro.css" type="text/css" rel="stylesheet">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
		<!-- js e Query -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
		<script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
		<script type="text/javascript" src="js/all-plugins.js"></script>
		<script type="text/javascript" src="js/plugin-active.js"></script>
		<script src="https://code.jquery.com/jquery.js"></script>
		<script src="https://code.jquery.com/jquery-3.1.1.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.quicksearch/2.3.1/jquery.quicksearch.js"></script>

		<script>		
			$(function(){
				$(".button-collapse").sideNav();
			});
		</script>
</head>
	<body>
		<!--MENU-->
		<nav class="navbar navbar-inverse">
			<div class="container">					
				<div class="menu">					
					<div class="navbar-header">			   
						<a class="navbar-brand" href="index.php">Home</a>
					</div>
					<div class="navbar-collapse collapse">
						<ul class="nav navbar-nav">
							<li class="active"><a href="grafico.php">Gráfico</a></li>				 
							<li><a href="configuracao.php">Configuração</a></li>
							<li><a href="sensores.php">Sensores</a></li>
							<li><a href="servos.php">Servos</a></li>
							<li><a href="cadastros.php">Cadastros</a></li>							
							<li><a href="admin/login.php">Sair</a></li> 
						</ul>
					</div>
				</div>
			</div>  
        </nav> 

		  
		