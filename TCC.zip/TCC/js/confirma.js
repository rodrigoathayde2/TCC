<script type="text/javascript">
$(document).ready(function(){
   $(".btn-excluir").click( function(event) {
      var apagar = confirm('Deseja realmente excluir este registro?');
      if (apagar){
		
      }else{
         event.preventDefault();
      }	
   });
});
</script>