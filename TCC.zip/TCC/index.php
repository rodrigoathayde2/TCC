<?php
include_once "php/header.php";
?>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Year', 'Água', 'Temperatura', 'Profit'],
          ['2014', 1000, 400, 200],
          ['2015', 1170, 460, 250],
          ['2016', 660, 1120, 300],
          ['2017', 1030, 540, 350]
        ]);

        var options = {
          chart: {
            title: 'Company Performance',
            subtitle: 'Água, Expenses, and Profit: 2014-2017',
          }
        };

        var chart = new google.charts.Bar(document.getElementById('columnchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
</script>
<style>
  img {max-width: 100%; max-height: 100%; border: none}
  .img_RR {max-width: 470px; max-height: 135px; margin-left: 30px}
  @media (max-width: 500px) {
      .img_RR {width: 100px}
  }
  #stop
  {
    position:absolute; 
    top:100%;
    left:95%;
    transform: translate(-50%, -50%);
  }
  #temperatura
  {
    position:absolute; 
    top:25%;
    left:50%;
    transform: translate(-50%, -50%);
  }
  #agua_tanque
  {
    position:absolute; 
    top:73%;
    left:43%;
    transform: translate(-50%, -50%);
  }
  #ligar_bomba
  {
    position:absolute; 
    top:75%;
    left:97%;
    transform: translate(-50%, -50%);
  }
  #flur
  {
    position:absolute; 
    top:60%;
    left:82%;
    transform: translate(-50%, -50%);
  }
  #php
  {
    position:absolute; 
    top:60%;
    left:67%;
    transform: translate(-50%, -50%);
  }

</style>
  <form method="POST" id="form_supervisorio"  name="supervisorio" class="form-horizontal">
  <!--CONTEÙDO-->
    <div class="conteudo">
      <img src="images/tcc.jpg" alt="tanque"/>
        <div style="text-align:left">
          <button id="stop" type="button" class="btn btn-danger" >STOP</button>
          <button id="temperatura" type="button" class="btn btn-warning">Temperatura</button>
          <button id="agua_tanque" type="button" class="btn btn-info">Água Tanque</button>
          <button id="ligar_bomba" type="button" class="btn btn-success">Ligar</button>
          <button id ="flur" type="button" class="btn btn-primary">Dosador Flur</button>
          <button id="php" type="button" class="btn btn-danger" >PHP</button>          
        </div>       
    </div>
  

  </form>
  <table class="table table-bordered table-dark">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Primeiro</th>
      <th scope="col">Último</th>
      <th scope="col">Nickname</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Mark</td>
      <td>Otto</td>
      <td>@mdo</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Jacob</td>
      <td>Thornton</td>
      <td>@fat</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td colspan="2">Larry the Bird</td>
      <td>@twitter</td>
    </tr>
  </tbody>
</table>
    
<?php
include_once "php/foolder.php";
?>