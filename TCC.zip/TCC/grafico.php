   <!--Gráfico-->
          <div id="columnchart_material" style="width: 600px; height: 400px;"></div>